// swiftlint:disable all
// Generated using SwiftGen — https://github.com/SwiftGen/SwiftGen

import Foundation

// swiftlint:disable superfluous_disable_command file_length implicit_return prefer_self_in_static_references

// MARK: - Strings

// swiftlint:disable explicit_type_interface function_parameter_count identifier_name line_length
// swiftlint:disable nesting type_body_length type_name vertical_whitespace_opening_braces
internal enum Localization {
  internal enum Components {
    internal enum Cells {
      internal enum CartProduct {
        /// StoreCartProductCellReuseIdentifier
        internal static let cellReuseIdentifier = Localization.tr("Localizable", "Components.Cells.CartProduct.cellReuseIdentifier", fallback: "StoreCartProductCellReuseIdentifier")
        internal enum CountLabel {
          /// %@ ITEM
          internal static func multiple(_ p1: Any) -> String {
            return Localization.tr("Localizable", "Components.Cells.CartProduct.CountLabel.multiple", String(describing: p1), fallback: "%@ ITEM")
          }
          /// 0 ITEM
          internal static let placeholder = Localization.tr("Localizable", "Components.Cells.CartProduct.CountLabel.placeholder", fallback: "0 ITEM")
          /// 1 ITEM
          internal static let unitary = Localization.tr("Localizable", "Components.Cells.CartProduct.CountLabel.unitary", fallback: "1 ITEM")
        }
        internal enum DiscountLabel {
          /// R$000,00
          internal static let placeholder = Localization.tr("Localizable", "Components.Cells.CartProduct.DiscountLabel.placeholder", fallback: "R$000,00")
        }
        internal enum NameLabel {
          /// placeholder
          internal static let placeholder = Localization.tr("Localizable", "Components.Cells.CartProduct.NameLabel.placeholder", fallback: "placeholder")
        }
        internal enum PriceLabel {
          /// R$000,00
          internal static let placeholder = Localization.tr("Localizable", "Components.Cells.CartProduct.PriceLabel.placeholder", fallback: "R$000,00")
        }
      }
      internal enum Product {
        /// StoreProductCellReuseIdentifier
        internal static let cellReuseIdentifier = Localization.tr("Localizable", "Components.Cells.Product.cellReuseIdentifier", fallback: "StoreProductCellReuseIdentifier")
        internal enum DiscountLabel {
          /// R$000,00
          internal static let placeholder = Localization.tr("Localizable", "Components.Cells.Product.DiscountLabel.placeholder", fallback: "R$000,00")
        }
        internal enum DiscountPercentageLabel {
          /// 00%
          internal static let placeholder = Localization.tr("Localizable", "Components.Cells.Product.DiscountPercentageLabel.placeholder", fallback: "00%")
        }
        internal enum InstallsmentsLabel {
          /// 1x R$ 00,00
          internal static let placeholder = Localization.tr("Localizable", "Components.Cells.Product.InstallsmentsLabel.placeholder", fallback: "1x R$ 00,00")
        }
        internal enum NameLabel {
          /// placeholder
          internal static let placeholder = Localization.tr("Localizable", "Components.Cells.Product.NameLabel.placeholder", fallback: "placeholder")
        }
        internal enum PriceLabel {
          /// R$000,00
          internal static let placeholder = Localization.tr("Localizable", "Components.Cells.Product.PriceLabel.placeholder", fallback: "R$000,00")
        }
        internal enum PromoLabel {
          /// PROMO
          internal static let text = Localization.tr("Localizable", "Components.Cells.Product.PromoLabel.text", fallback: "PROMO")
        }
      }
    }
    internal enum Views {
      internal enum ValueConfirmation {
        internal enum CompleteButton {
          /// Completar
          internal static let placeholder = Localization.tr("Localizable", "Components.Views.ValueConfirmation.CompleteButton.placeholder", fallback: "Completar")
        }
        internal enum DescriptionLabel {
          /// Total
          internal static let placeholder = Localization.tr("Localizable", "Components.Views.ValueConfirmation.DescriptionLabel.placeholder", fallback: "Total")
        }
        internal enum PriceLabel {
          /// R$000,00
          internal static let placeholder = Localization.tr("Localizable", "Components.Views.ValueConfirmation.PriceLabel.placeholder", fallback: "R$000,00")
        }
      }
    }
  }
  internal enum Features {
    internal enum BestSellers {
      /// Mais Vendidos
      internal static let navigationTitle = Localization.tr("Localizable", "Features.BestSellers.navigationTitle", fallback: "Mais Vendidos")
      internal enum Filter {
        /// Cancelar
        internal static let cancel = Localization.tr("Localizable", "Features.BestSellers.Filter.cancel", fallback: "Cancelar")
        /// Apagar Filtros
        internal static let removeAll = Localization.tr("Localizable", "Features.BestSellers.Filter.removeAll", fallback: "Apagar Filtros")
        /// Selecione um filtro
        internal static let title = Localization.tr("Localizable", "Features.BestSellers.Filter.title", fallback: "Selecione um filtro")
        internal enum Cases {
          /// Em promoção
          internal static let inPromotion = Localization.tr("Localizable", "Features.BestSellers.Filter.Cases.inPromotion", fallback: "Em promoção")
        }
      }
    }
    internal enum Cart {
      /// Carrinho
      internal static let navigationTitle = Localization.tr("Localizable", "Features.Cart.navigationTitle", fallback: "Carrinho")
      internal enum ConfirmationView {
        /// CONTINUAR
        internal static let buttonText = Localization.tr("Localizable", "Features.Cart.ConfirmationView.buttonText", fallback: "CONTINUAR")
        /// TOTAL
        internal static let descriptionText = Localization.tr("Localizable", "Features.Cart.ConfirmationView.descriptionText", fallback: "TOTAL")
      }
      internal enum EmptyCartLabel {
        /// O carrinho está vazio
        internal static let text = Localization.tr("Localizable", "Features.Cart.EmptyCartLabel.text", fallback: "O carrinho está vazio")
      }
      internal enum RemovalConfirmation {
        /// Cancelar
        internal static let cancel = Localization.tr("Localizable", "Features.Cart.RemovalConfirmation.cancel", fallback: "Cancelar")
        /// %@ vai sentir falta de você!
        internal static func message(_ p1: Any) -> String {
          return Localization.tr("Localizable", "Features.Cart.RemovalConfirmation.message", String(describing: p1), fallback: "%@ vai sentir falta de você!")
        }
        /// Remover
        internal static let remove = Localization.tr("Localizable", "Features.Cart.RemovalConfirmation.remove", fallback: "Remover")
        /// Deseja mesmo remover?
        internal static let title = Localization.tr("Localizable", "Features.Cart.RemovalConfirmation.title", fallback: "Deseja mesmo remover?")
      }
    }
    internal enum ProductDetails {
      /// Detalhes do produto
      internal static let navigationTitle = Localization.tr("Localizable", "Features.ProductDetails.navigationTitle", fallback: "Detalhes do produto")
      internal enum DiscountLabel {
        /// R$000,00
        internal static let placeholder = Localization.tr("Localizable", "Features.ProductDetails.DiscountLabel.placeholder", fallback: "R$000,00")
      }
      internal enum DiscountPercentageLabel {
        /// 00%
        internal static let placeholder = Localization.tr("Localizable", "Features.ProductDetails.DiscountPercentageLabel.placeholder", fallback: "00%")
      }
      internal enum InstallsmentsLabel {
        /// 1x R$ 00,00
        internal static let placeholder = Localization.tr("Localizable", "Features.ProductDetails.InstallsmentsLabel.placeholder", fallback: "1x R$ 00,00")
      }
      internal enum NameLabel {
        /// placeholder
        internal static let placeholder = Localization.tr("Localizable", "Features.ProductDetails.NameLabel.placeholder", fallback: "placeholder")
      }
      internal enum PriceLabel {
        /// R$000,00
        internal static let placeholder = Localization.tr("Localizable", "Features.ProductDetails.PriceLabel.placeholder", fallback: "R$000,00")
      }
      internal enum PromoLabel {
        /// PROMO
        internal static let text = Localization.tr("Localizable", "Features.ProductDetails.PromoLabel.text", fallback: "PROMO")
      }
      internal enum AddToCartButton {
        /// ADICIONAR AO CARRINHO
        internal static let text = Localization.tr("Localizable", "Features.ProductDetails.addToCartButton.text", fallback: "ADICIONAR AO CARRINHO")
      }
    }
  }
  internal enum Generic {
    internal enum AddToCart {
      internal enum Multiple {
        /// Cancelar
        internal static let cancel = Localization.tr("Localizable", "Generic.AddToCart.Multiple.cancel", fallback: "Cancelar")
        /// Agora selecione o tamanho de %@:
        internal static func message(_ p1: Any) -> String {
          return Localization.tr("Localizable", "Generic.AddToCart.Multiple.message", String(describing: p1), fallback: "Agora selecione o tamanho de %@:")
        }
        /// Boa Escolha!
        internal static let title = Localization.tr("Localizable", "Generic.AddToCart.Multiple.title", fallback: "Boa Escolha!")
      }
      internal enum Unitary {
        /// OK
        internal static let confirm = Localization.tr("Localizable", "Generic.AddToCart.Unitary.confirm", fallback: "OK")
        /// Você adicionou um %@ de tamanho %@
        internal static func message(_ p1: Any, _ p2: Any) -> String {
          return Localization.tr("Localizable", "Generic.AddToCart.Unitary.message", String(describing: p1), String(describing: p2), fallback: "Você adicionou um %@ de tamanho %@")
        }
        /// Boa Escolha!
        internal static let title = Localization.tr("Localizable", "Generic.AddToCart.Unitary.title", fallback: "Boa Escolha!")
      }
    }
    internal enum Coder {
      /// Localizable.strings
      ///   Store
      /// 
      ///   Created by Samuel Brasileiro on 26/05/23.
      internal static let fatalError = Localization.tr("Localizable", "Generic.Coder.FatalError", fallback: "init(coder:) has not been implemented")
    }
  }
}
// swiftlint:enable explicit_type_interface function_parameter_count identifier_name line_length
// swiftlint:enable nesting type_body_length type_name vertical_whitespace_opening_braces

// MARK: - Implementation Details

extension Localization {
  private static func tr(_ table: String, _ key: String, _ args: CVarArg..., fallback value: String) -> String {
    let format = BundleToken.bundle.localizedString(forKey: key, value: value, table: table)
    return String(format: format, locale: Locale.current, arguments: args)
  }
}

// swiftlint:disable convenience_type
private final class BundleToken {
  static let bundle: Bundle = {
    #if SWIFT_PACKAGE
    return Bundle.module
    #else
    return Bundle(for: BundleToken.self)
    #endif
  }()
}
// swiftlint:enable convenience_type
