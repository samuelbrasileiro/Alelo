//
//  StoreFilterKind.swift
//  Store
//
//  Created by Samuel Brasileiro on 27/05/23.
//

import Foundation

enum StoreFilterKind {
    case inPromotion
}
