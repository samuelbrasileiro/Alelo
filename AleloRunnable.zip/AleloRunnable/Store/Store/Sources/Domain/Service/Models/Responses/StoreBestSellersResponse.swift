//
//  StoreBestSellersResponse.swift
//  Store
//
//  Created by Samuel Brasileiro on 26/05/23.
//

import Foundation

// MARK: - StoreBestSellersResponse
struct StoreBestSellersResponse: Codable {
    var products: [StoreProduct]
}
